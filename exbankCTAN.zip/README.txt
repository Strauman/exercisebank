Files:
- exbank.sty : The exercise bank
- manual.pdf : Description of how the package works
- example.zip : containing example
  -- example.tex : example of use
  -- exercises/ : Directory containing exercises that could be use
    -- firstexercise.tex: example exercise
    -- secondexercise.tex: example exercise
    -- thirdexercise.tex: example exercise
